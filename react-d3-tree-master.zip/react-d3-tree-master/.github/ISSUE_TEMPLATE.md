Thank you for taking the time to report an issue with react-d3-tree!  

Feel free to delete any questions that do not apply.

## Are you reporting a bug, or opening a feature request?
[Replace with your answer]
  
## What is the actual behavior/output?
[Replace with your answer if relevant]

## What is the behavior/output you expect?
[Replace with your answer if relevant]

## Can you consistently reproduce the issue/create a reproduction case (e.g. on https://codesandbox.io)?
[Replace with your answer if relevant]

## What version of react-d3-tree are you using?
[Replace with your answer]

## If react-d3-tree crashed with a traceback, please paste the full traceback below.
[Replace with your traceback]
